package fr.caensup.contacts

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ContactsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
