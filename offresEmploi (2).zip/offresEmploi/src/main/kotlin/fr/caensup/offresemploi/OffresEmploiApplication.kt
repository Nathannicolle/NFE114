package fr.caensup.offresemploi

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class OffresEmploiApplication

fun main(args: Array<String>) {
    runApplication<OffresEmploiApplication>(*args)
}
