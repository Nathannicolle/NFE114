package fr.caensup.offresemploi.entities

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
open class Entreprise {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    open var id: Int? = null;
}